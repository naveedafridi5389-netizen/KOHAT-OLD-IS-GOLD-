KOHAT OLD IS GOLD website preview

Business details configured:
- WhatsApp: 03211118866
- Nationwide delivery: Yes
- Payment: Cash on Delivery or Easypaisa to 03211118866

How to preview:
1. Open index.html in a browser.
2. Add sample products to the cart and use the WhatsApp order button.
3. Replace demo products/prices with actual stock before launch.

Important:
- This is a front-end prototype, not a fully hosted ecommerce platform.
- Easypaisa payments are not automatically verified or collected by this website. Customers should confirm the order and payment instructions with the seller on WhatsApp.
- Real product inventory, admin dashboard, shipping integration, and live order database still need setup.
